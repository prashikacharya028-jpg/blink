Blink (installable web app)

1. Host this whole folder over HTTPS (Netlify Drop, Vercel, GitHub Pages, Cloudflare Pages all work for free).
2. Open the URL on your phone.
   - iPhone: Safari > Share > Add to Home Screen
   - Android: Chrome > menu > Install app
3. It opens full screen like a native app and works offline after the first load.

Local test: run  python3 -m http.server 8000  in this folder, then open http://localhost:8000
(The camera needs HTTPS or localhost.)
